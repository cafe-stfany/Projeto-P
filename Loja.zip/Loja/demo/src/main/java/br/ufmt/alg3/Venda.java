package br.ufmt.alg3;

public class Venda {

}
